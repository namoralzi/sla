function toggleMusic() {
  const music = document.getElementById("musica");
  if (music.paused) {
    music.play();
  } else {
    music.pause();
  }
}
